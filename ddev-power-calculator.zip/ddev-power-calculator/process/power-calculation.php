<?php

if (!function_exists('ddev_power_calculation')) {
    function ddev_power_calculation()
    {
        return '<div id="app">
                    <power-component></power-component>
                </div>
                ';
    }
}
